package priprema;
import java.util.Map;
import java.util.TreeMap;

public class Grad {
	private String ime;
	private Map<String, Boolean> ljudi;
	private int brojUspjesnoVakcinisanih = 0;
	
	public Grad(String ime) {
		this.ime = ime;
		ljudi = new TreeMap<>();
	}
	
	public String getIme() {
		return ime;
	}
	
	public Map<String, Boolean> getLjudi(){
		return ljudi;
	}
	
	public void dodajOsobu(String jmbg, boolean uspjeh) {
		ljudi.put(jmbg, uspjeh);
		
		if(uspjeh)
			brojUspjesnoVakcinisanih ++;
	}
	
	public String toString() {
		
		if(brojUspjesnoVakcinisanih == 0)
			return "";
	
		StringBuffer sb = new StringBuffer();
		sb.append(ime + "\n");
		
		for(Map.Entry<String,Boolean> ulaz : ljudi.entrySet()) {
			String jmbg = ulaz.getKey();
			Boolean uspjeh = ulaz.getValue();
			
			if(uspjeh)
				sb.append(jmbg+"\n");
		}
		return sb.toString();
			
	}

}
