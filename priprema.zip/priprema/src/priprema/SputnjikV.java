package priprema;
import java.util.Random;

public class SputnjikV extends Vakcina {
	
	private String vektor;
	private int brMjeseci;
	
	public SputnjikV (String identifikator, String vektor, int brMjeseci) {
		super(identifikator);
		this.vektor = vektor;
		this.brMjeseci = brMjeseci;
	}
	
	public String getVektor() {
		return vektor;
	}
	
	public int getBrMjeseci() {
		return brMjeseci;
	}

	@Override
	public boolean vakcinisi() {
		broj++;
		
		Random ran = new Random(java.lang.System.currentTimeMillis());
		
		if(vektor.compareTo("RNK") == 0)
			return true;
		else if(vektor.compareTo("DNK") == 0)
			return ran.nextBoolean();
		else				
			return false;
	}
	@Override
	public String toString() {
		return identifikator + " " + vektor + " " + brMjeseci;
	}
}
