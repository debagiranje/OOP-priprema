package priprema;
import java.util.Random;

public class Fajzer extends Vakcina {
	
	private Jacina jacinaDoze;
	
	public Fajzer(String identifikator, Jacina jacinaDoze) {
		super(identifikator);
		this.jacinaDoze = jacinaDoze;
	}
	
	public Jacina getJacinaDoze() {
		return jacinaDoze;
	}

	@Override
	public boolean vakcinisi(){
		broj++;
		
		Random ran = new Random(java.lang.System.currentTimeMillis());
		int randomInt = ran.nextInt(100);
		
		switch(jacinaDoze) {
		case SLABA: return randomInt < 30;
		case SREDNJA: return randomInt < 60;
		case JAKA: return randomInt < 90;
		default: return false;
		}
	}
	
	public String toString() {
		return identifikator + " " + jacinaDoze.toString();
	}

}
