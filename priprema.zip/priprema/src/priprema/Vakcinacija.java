package priprema;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.io.IOException;

import java.util.List;
import java.util.ArrayList;

public class Vakcinacija extends Application{
	
	private List <Vakcina> vakcine = new ArrayList<>();
	private List <Grad> gradovi = new ArrayList<>();

	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) {
		
		VBox vBoxRoot = new VBox(10);
		vBoxRoot.setPadding(new Insets(10, 10, 10, 10));
		
		HBox hBoxTop = new HBox(10);
		TextArea textAreaDostupneVakcine = new TextArea("");
		HBox hBoxMiddle = new HBox(10);
		TextArea textAreaIzvjestaj = new TextArea("");
		
		vBoxRoot.getChildren().addAll(hBoxTop, textAreaDostupneVakcine, hBoxMiddle, textAreaIzvjestaj);
		
		//////////////////////////////////////////////////////////////////////////////////////////////
		/*hBoxTop elementi*/
		
		Button btnUcitaj = new Button("Ucitaj");
		
		RadioButton rbtnSortirano = new RadioButton("sortirano");
		RadioButton rbtnOriginalno = new RadioButton("originalno");
		ToggleGroup tg = new ToggleGroup();
		rbtnSortirano.setToggleGroup(tg);
		rbtnOriginalno.setToggleGroup(tg);
		rbtnSortirano.setSelected(true);
		
		Button btnIzvjestaj = new Button("Izvjestaj");
		
		hBoxTop.setAlignment(Pos.CENTER);
		hBoxTop.getChildren().addAll(btnUcitaj,rbtnSortirano,rbtnOriginalno,btnIzvjestaj);
		
		
		///////////////////////////////////////////////////////////////////////////////////////////
		/*hBoxMiddle*/
		
		Label labelGrad = new Label("Grad:");
		TextField tfGrad = new TextField("");
		Label labelJMBG = new Label("JMBG:");
		TextField tfJMBG = new TextField("");
		Button btnVakcinisi = new Button("Vakcinisi");
		
		hBoxMiddle.getChildren().addAll(labelGrad,tfGrad,labelJMBG,tfJMBG,btnVakcinisi);
				
		//////////////////////////////////////////////////////////////////////////////////////////
		
		btnUcitaj.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				textAreaDostupneVakcine.clear();
				textAreaIzvjestaj.clear();
				
				Path putanja = Paths.get("src/vakcine.txt");
				
				try {
					List<String> linije = Files.readAllLines(putanja);
					
					vakcine = new ArrayList<>();
					
					for(String l:linije) {
						String [] s = l.split(",");
						
						if(s.length == 2) {
							Fajzer f = new Fajzer(s[0].trim(), Jacina.izBroja(Integer.parseInt(s[1].trim())));
							vakcine.add(f);							
						}
						else if(s.length == 3) {
							SputnjikV sputnjikV = new SputnjikV (s[0].trim(), s[1].trim(), Integer.parseInt(s[2].trim()));
							vakcine.add(sputnjikV);
						}
						else
							throw new RuntimeException("Datoteka nije u dobrom formatu");
					}
					
					if(rbtnSortirano.isSelected()) {
						KomparatorVakcina komparator = new KomparatorVakcina();
						Collections.sort(vakcine,komparator);
					}
					//System.out.println(vakcine.size());
					for(Vakcina v:vakcine)
						textAreaDostupneVakcine.appendText(v.toString() + "\n");
					
				}
				catch(Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		
		//////////////////////////////////////////////////////////////////////////////////////////
		btnVakcinisi.setOnAction(new EventHandler <ActionEvent>(){
			public void handle(ActionEvent event) {
			String imeGrada = tfGrad.getText();
			String JMBG = tfJMBG.getText();
			
			Grad grad = null;
			for(Grad g : gradovi)
				if(g.getIme().compareTo(imeGrada) == 0)
					grad = g;
			if(grad == null) {
				grad = new Grad(imeGrada);
				gradovi.add(grad);
			}
			
			if(vakcine.isEmpty()) {
				textAreaIzvjestaj.appendText("Nema vise vakcina!");
				return;
			}
			
			Vakcina v = vakcine.remove(0);
			boolean uspjehVakcinacije = v.vakcinisi();
			
			grad.dodajOsobu(JMBG, uspjehVakcinacije);
			
			textAreaIzvjestaj.appendText(imeGrada + ": " + JMBG + " je vakcinisan " + v.getIdentifikator() + ". \n");
			
			if(uspjehVakcinacije)
				textAreaIzvjestaj.appendText(" \t Vakcinacija je uspjesna.\n");
			else
				textAreaIzvjestaj.appendText(" \t Vakcinacija nije uspjesna.\n");
			}
			
		});
		
		//////////////////////////////////////////////////////////////////////////////////////////
		btnIzvjestaj.setOnAction(e->{//new EventHandler <ActionEvent>() {
	//		public void handle(ActionEvent event) {
				
				textAreaIzvjestaj.clear();
				
				for(Grad grad : gradovi)
					textAreaIzvjestaj.appendText(grad.toString());
				
				textAreaIzvjestaj.appendText("\n");
				textAreaIzvjestaj.appendText("Ukupno vakcinisanh je : " + Vakcina.broj);
				
			//}
		});
		
//////////////////////////////////////////////////////////////////////////////////////////
		
		Scene scena = new Scene(vBoxRoot, 570, 470);
		primaryStage.setScene(scena);
		primaryStage.setTitle("Vakcinacija");
		primaryStage.show();
		
		
		
		
		
	}
	
	

}
