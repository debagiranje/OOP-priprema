import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Aplikacija extends Application  {

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		Racun racun = new Racun(true);
		
		VBox root = new VBox(10);
		root.setPadding(new Insets(10));
		
		HBox hbSifra = new HBox(10);
		HBox hbKolicina = new HBox(10);
		HBox hbRacunBtns = new HBox(10);
		HBox hbTotal = new HBox(10);
		
		Label lblSifra = new Label("Sifra artikla: ");
		TextField tfSifra = new TextField();
		hbSifra.getChildren().addAll(lblSifra, tfSifra);
		
		Label lblKolicina = new Label("Kolicina artikla: ");
		TextField tfKolicina = new TextField();
		hbKolicina.getChildren().addAll(lblKolicina, tfKolicina);

		Button btnRacuunPotvrdi = new Button("Potvrdi");
		Button btnRacuunSacuvaj = new Button("Sacuvaj");
		hbRacunBtns.getChildren().addAll(btnRacuunPotvrdi, btnRacuunSacuvaj);

		TableView tabelaRacun = new TableView();

		Label lblTotal = new Label("Ukupni isnos: 0.0");
		
		Label lblRacunGreska = new Label("");
		lblRacunGreska.setTextFill(Color.RED);
		
		VBox vb_racun = new VBox(10);
		vb_racun.getChildren().addAll(hbSifra, hbKolicina, hbRacunBtns, tabelaRacun, lblTotal, lblRacunGreska);
		
		vb_racun.setVisible(false);
		vb_racun.setManaged(false);
		
		HBox hbNoviRacunNajprodavanijiArtikal = new HBox(10);
		Button btnNoviRacun = new Button("Novi racun");
		Button btnNajprodavanijiArtikal = new Button("Najprodavaniji artikal");
		hbNoviRacunNajprodavanijiArtikal.getChildren().addAll(btnNoviRacun, btnNajprodavanijiArtikal);
		
		HBox hbSakrijArtikal = new HBox(10);
		Label lblSpisakArtikala = new Label("Spisak artikala u ponudi:");
		Button btnSakrijArtikale = new Button("Sakrij artikle");
		hbSakrijArtikal.getChildren().addAll(lblSpisakArtikala, btnSakrijArtikale);
		TableView tabelaArtikala = new TableView();
		
		// treba dodati na kraju
		// root.getChildren().addAll(racun, btnNoviRacun, btnNajprodavanijiArtikal, hbSakrijArtikal, tabelaArtikala);
		
		// popunimo tabelu za prikaz svih artikala 
		TreeMap<String, Artikal> spisakArtikala = Artikal.getSpisakArtikala();
	    TableColumn<Map, String> sifraColumn = new TableColumn<>("Sifra");
	    sifraColumn.setCellValueFactory(new MapValueFactory<>("sifra"));
	    TableColumn<Map, String> nazivColumn = new TableColumn<>("Naziv");
	    nazivColumn.setCellValueFactory(new MapValueFactory<>("naziv"));
	    TableColumn<Map, Float> kolicinaColumn = new TableColumn<>("Kolicina");
	    kolicinaColumn.setCellValueFactory(new MapValueFactory<>("kolicina"));
	    TableColumn<Map, Float> cijenaColumn = new TableColumn<>("Cijena");
	    cijenaColumn.setCellValueFactory(new MapValueFactory<>("cijena"));

	    tabelaArtikala.getColumns().addAll(sifraColumn, nazivColumn, kolicinaColumn, cijenaColumn);
	    
	    ObservableList<Map<String, Object>> ArtikliUPonudi =
	    	    FXCollections.<Map<String, Object>>observableArrayList();
	    
	    for(Artikal artikal:spisakArtikala.values()) {
			Map<String, Object> item = new HashMap<>();
			item.put("sifra", artikal.getSifra());
			item.put("naziv" , artikal.getNaziv());
			item.put("kolicina", artikal.getKolicina());
			item.put("cijena" , artikal.getCijena());
			ArtikliUPonudi.add(item);	
	    }
	    tabelaArtikala.getItems().addAll(ArtikliUPonudi);

		
		// popunimo tabelu za prikaz artikala koji se nalaze na racunu
	    TableColumn<Map, String> racunNazivArtikla = new TableColumn<>("Naziv Artikla");
	    racunNazivArtikla.setCellValueFactory(new MapValueFactory<>("naziv"));
	    TableColumn<Map, String> racunKolicina = new TableColumn<>("Kolicina");
	    racunKolicina.setCellValueFactory(new MapValueFactory<>("kolicina"));
	    TableColumn<Map, Float> racunCijena = new TableColumn<>("Cijena");
	    racunCijena.setCellValueFactory(new MapValueFactory<>("cijena"));
	    TableColumn<Map, Float> racunIznos = new TableColumn<>("Iznos");
	    racunIznos.setCellValueFactory(new MapValueFactory<>("iznos"));

	    tabelaRacun.getColumns().addAll(racunNazivArtikla, racunKolicina, racunCijena, racunIznos);

	    
	    btnNoviRacun.setOnAction(e -> {
	    	vb_racun.setVisible(true);
	    	vb_racun.setManaged(true);
			hbNoviRacunNajprodavanijiArtikal.setVisible(false);
			hbNoviRacunNajprodavanijiArtikal.setManaged(false);
	    });
	    
	    btnRacuunSacuvaj.setOnAction(e -> {
	    	vb_racun.setVisible(false);
	    	vb_racun.setManaged(false);
			hbNoviRacunNajprodavanijiArtikal.setVisible(true);
			hbNoviRacunNajprodavanijiArtikal.setManaged(true);
			
			racun.sacuvajRacun();
			tabelaRacun.getItems().clear();
		    tfSifra.clear();
		    tfKolicina.clear();
		    
		    lblSpisakArtikala.setText("" + Racun.sviRacuni.size());
		    
	    });
	    
	    btnRacuunPotvrdi.setOnAction(e -> {
	    	lblRacunGreska.setText("");
	    	String sifraArtikla = tfSifra.getText();
	    	String strKolicina = tfKolicina.getText();
	    	float kolicina = 0;
    		try {
    			kolicina = Float.parseFloat(strKolicina);
    		} catch(Exception ex) {
    			lblRacunGreska.setText("Pogresan unos!");
	    		return;
    		}
    		
    		float iznos = racun.kupiArtikal(sifraArtikla, kolicina);
			if(iznos == -1) {
				lblRacunGreska.setText("Pogresan unos!");
	    		return;
			}
			
			tabelaArtikala.getItems().clear();
			tabelaRacun.getItems().clear();
			lblTotal.setText("");
			
		    for(Artikal art:spisakArtikala.values()) {
				Map<String, Object> item = new HashMap<>();
				item.put("sifra", art.getSifra());
				item.put("naziv" , art.getNaziv());
				item.put("kolicina", art.getKolicina());
				item.put("cijena" , art.getCijena());
				tabelaArtikala.getItems().add(item);
		    }
		    
			float totalIznos = 0;
		    for(Map.Entry<Artikal, Float> artikalKolicina:racun.kupljeniArtikli.entrySet()) {
				Map<String, Object> item = new HashMap<>();
				item.put("naziv", artikalKolicina.getKey().getNaziv());
				item.put("kolicina" , artikalKolicina.getValue());
				item.put("cijena", artikalKolicina.getKey().getCijena());
				iznos = artikalKolicina.getKey().getCijena() * artikalKolicina.getValue();
				item.put("iznos" , iznos);
				tabelaRacun.getItems().add(item);
				totalIznos += iznos;
		    }
		    lblTotal.setText("Ukupni isnos: " + totalIznos);
		    tfSifra.clear();
		    tfKolicina.clear();
	    });

	    root.getChildren().addAll(vb_racun, hbNoviRacunNajprodavanijiArtikal, hbSakrijArtikal, tabelaArtikala);
	    Scene scene = new Scene(root,450,450);
	    primaryStage.setScene(scene);
	    primaryStage.show();
	}

	public static void main(String[] args) {
		Artikal.ucitajDatoteku("artikal.txt");
		launch(args);
	}

}
