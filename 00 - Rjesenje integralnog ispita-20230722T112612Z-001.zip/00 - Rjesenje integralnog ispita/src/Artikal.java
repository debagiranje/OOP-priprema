import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.TreeMap;

public class Artikal  implements Comparable<Artikal>{
	private String sifra;
	private String naziv;
	private float kolicinaZaliha;
	private float cijena;
	private static TreeMap<String, Artikal> spisakArtikala = new TreeMap<>();
	
	public Artikal(String sifra, String naziv, float cijena, float kolicinaZaliha) {
		this.sifra = sifra;
		this.naziv = naziv;
		this.cijena = cijena;
		this.kolicinaZaliha = kolicinaZaliha;
		
		boolean prisutan = false;
		for(String s: spisakArtikala.keySet())
			if(sifra.equals(s)) {
				prisutan = true;
				break;
			}
		if(!prisutan)
			spisakArtikala.put(sifra, this);
	}
	
	public static boolean ucitajDatoteku(String filename) {
		Path ulaznaPutanja = Paths.get(filename);
		
		try {
			List<String> linije = Files.readAllLines(ulaznaPutanja, StandardCharsets.UTF_8);
			// i<linije.size()-1 jer postoji mogucnost da zadnja linija bude prazna
			for(int i=0; i<linije.size()-1; i+=4)
			{
				String sifra = linije.get(i);
				String naziv = linije.get(i+1);
				float zalihe = Float.parseFloat(linije.get(i+2));
				float cijena = Float.parseFloat(linije.get(i+3));
				new Artikal(sifra, naziv, cijena, zalihe);
				
			}
		} catch (IOException e) {
			System.err.println("Neuspjesno citanje sadrzaja datoteke!");
			return false;
		}
		
		return true;
	}
	
	public static Artikal getArtikal(String sifra) {
		return spisakArtikala.get(sifra);
	}
	
	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public float getKolicina() {
		return kolicinaZaliha;
	}

	public void povecajKolicinuZaliha(float k) {
		this.kolicinaZaliha += k;
	}
	
	public void smanjiKolicinuZaliha(float k) {
		this.kolicinaZaliha -= k;
	}

	public float getCijena() {
		return cijena;
	}

	public String getSifra() {
		return sifra;
	}

	public static TreeMap<String, Artikal> getSpisakArtikala() {
		return spisakArtikala;
	}

	public String toString() {
		String res = "\nSifra "+sifra;
		res += "\nNaziv "+naziv;
		res += "\nKolicina "+kolicinaZaliha;
		res += "\nCijena "+cijena;
		return res;
	}
	

	@Override
	public int compareTo(Artikal o) {
		return this.sifra.compareTo(o.getSifra());
	}
	
	public static Artikal najprodavanijiArtikal() {
		return Racun.najprodavanijiArtikal();
	}
}
