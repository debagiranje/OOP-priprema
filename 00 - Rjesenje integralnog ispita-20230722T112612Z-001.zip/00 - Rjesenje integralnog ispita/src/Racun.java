import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;


public class Racun {
	public int ID;
	private static int brojac = 0;
	public static LinkedList<Racun> sviRacuni = new LinkedList<>();
	public Map<Artikal, Float> kupljeniArtikli;
	
	public Racun() {
		this.ID = brojac;
		brojac++;
		kupljeniArtikli = new TreeMap<>();
		sviRacuni.add(this);
	}	
	
	public Racun(boolean pozivIzGUI) {
		if(!pozivIzGUI) {
			this.ID = brojac;
			brojac++;
			kupljeniArtikli = new TreeMap<>();
			sviRacuni.add(this);
		}
		else
			kupljeniArtikli = new TreeMap<>();
	}
	
	public Racun(Racun racun) {
		this.ID = brojac;
		brojac++;
		kupljeniArtikli = new TreeMap<>(racun.kupljeniArtikli);
		sviRacuni.add(this);
	}
	
	public float kupiArtikal(String sifraArtikla, float kolicina) {
		/*
		 * return -1 ukoliko je neuspijesna kupivina, u protivnom vrati iznos kupljenog artikla
		 */
		Artikal artikal = Artikal.getArtikal(sifraArtikla);
		if(artikal == null)
			return  -1;
		float kolicinaZalihaArtikla = artikal.getKolicina();
		if(kolicinaZalihaArtikla < kolicina || kolicina < 0)
			return -1;
		
		artikal.smanjiKolicinuZaliha(kolicina);
		
		if(kupljeniArtikli.containsKey(artikal))
			kolicina += kupljeniArtikli.get(artikal);
		kupljeniArtikli.put(artikal, kolicina);
		return artikal.getCijena() * kolicina;
	}
	
	public static Artikal najprodavanijiArtikal() {
		/*
		 * Uzima sve racune i sabira za svaki artikal u kojij je kolicini prodat
		 * Staticna metoda jer se trazi uopste najprodavaniji a ne na jednom racunu
		 */
		
		Map<Artikal, Float> artikalKolicinaKupovine = new TreeMap<>();

		for(Racun r:sviRacuni) 
			for(Map.Entry<Artikal, Float>par:r.kupljeniArtikli.entrySet()) 
			{
				float kolicina = par.getValue();
				if(artikalKolicinaKupovine.containsKey(par.getKey()))
					kolicina += artikalKolicinaKupovine.get(par.getKey());
				artikalKolicinaKupovine.put(par.getKey(), kolicina);		
			}
		
		Artikal trazeniArtikal = null;
		float maxKolicina = 0;
		for(Map.Entry<Artikal, Float> mapArtikal:artikalKolicinaKupovine.entrySet())
			if(mapArtikal.getValue() > maxKolicina) {
				maxKolicina = mapArtikal.getValue();
				trazeniArtikal = mapArtikal.getKey();
			}
		
		/*
		// drugi nacin
		Artikal trazeniArtikal = artikalKolicinaKupovine.entrySet()
				                                        .stream()
				                                        .max((artikal1, artikal2) -> artikal1.getValue().compareTo(artikal2.getValue()))
				                                        .get()
				                                        .getKey();
		// treci nacin		                                        
		Artikal trazeniArtikal = artikalKolicinaKupovine.entrySet()
				                                        .stream()
				                                        .max((artikal1, artikal2) -> artikal1.getValue() > artikal2.getValue()? -1 : 1)
				                                        .get()
				                                        .getKey();
		*/
		return trazeniArtikal;
	}
	
	public void sacuvajRacun() {
		new Racun(this);
		this.kupljeniArtikli.clear();
	}

}
